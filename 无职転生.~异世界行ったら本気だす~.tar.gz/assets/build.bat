@echo off
cd /d "%~dp0"
pyinstaller --noconfirm --clean game.spec
echo.
echo Build finished. Output folder: dist
pause
