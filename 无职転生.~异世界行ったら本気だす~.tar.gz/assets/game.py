import pygame
import sys
import os
import asyncio


# 打包进程序的中文字体文件（放在项目 fonts 目录下）
FONT_PATH = "fonts/simhei.ttf"

# 字体缓存，避免每帧重新加载字体文件
_font_cache = {}


def resource_path(relative):
    """返回资源路径：
    - PyInstaller 打包后：指向解包目录 _MEIPASS
    - 源码运行 / pygbag 网页运行：直接用相对路径
    """
    base = getattr(sys, "_MEIPASS", None)
    if base:
        return os.path.join(base, relative)
    return relative


# 初始化
pygame.init()

# 窗口尺寸
WIDTH = 712
HEIGHT = 400

# 游戏场景：角色尺寸（缩小后的人物模型）
CHARACTER_SIZE = 110
# 地面高度（角色底边落点，y 坐标向下增长）
GROUND_Y = HEIGHT - CHARACTER_SIZE - 20

# 移动与跳跃参数
MOVE_SPEED = 5
JUMP_SPEED = -11    # 负数表示向上跳，数值越小跳跃高度越低
GRAVITY = 0.9      # 每帧下落加速度
MAX_JUMPS = 2      # 允许的跳跃次数（二段跳）

# 窗口（关卡）数量
BLANK_LEVELS = 15                # 15 个纯白背景窗口
TOTAL_LEVELS = BLANK_LEVELS + 1  # 第 1 个是游戏窗口，后面 15 个是纯白背景窗口

# 切换窗口后的短暂冷却帧数，防止同一次进入左右冲突
TRANSITION_COOLDOWN = 10


def get_font(size):
    """返回支持中文的字体：优先用打包的 simhei.ttf，找不到时回退系统字体，再回退默认字体。"""
    if size in _font_cache:
        return _font_cache[size]

    font = None
    try:
        font = pygame.font.Font(resource_path(FONT_PATH), size)
    except Exception:
        font = None

    if font is None:
        for name in ["microsoftyahei", "simhei", "simsun", "dengxian"]:
            path = pygame.font.match_font(name)
            if path:
                font = pygame.font.Font(path, size)
                break

    if font is None:
        font = pygame.font.Font(None, size)

    _font_cache[size] = font
    return font


def load_scaled(path, size, fallback_color):
    """加载并缩放图片；失败时返回纯色后备图。"""
    try:
        image = pygame.image.load(path)
        return pygame.transform.scale(image, size)
    except pygame.error as e:
        print(f"图片加载失败 {path}: {e}")
        surface = pygame.Surface(size)
        surface.fill(fallback_color)
        return surface


def load_images():
    """加载背景与角色图片。
    主菜单使用 l1（js1）；游戏场景向前走用 js4，向后走用 js3。"""
    background = load_scaled(resource_path("背景/背景1.png"), (WIDTH, HEIGHT), (100, 150, 200))

    # 主菜单角色：l1（js1）
    character_menu = load_scaled(resource_path("角色/l1.png"), (300, 300), (255, 200, 150))

    # 向前走：js4
    character_front_small = load_scaled(resource_path("角色/js4.png"), (CHARACTER_SIZE, CHARACTER_SIZE), (255, 200, 150))

    # 向后走：js3
    character_back_small = load_scaled(resource_path("角色/js3.png"), (CHARACTER_SIZE, CHARACTER_SIZE), (200, 220, 255))

    # 站立不动：l1
    character_idle_small = load_scaled(resource_path("角色/l1.png"), (CHARACTER_SIZE, CHARACTER_SIZE), (255, 200, 150))

    # 按下键（下蹲）：l6
    character_down_small = load_scaled(resource_path("角色/l6.png"), (CHARACTER_SIZE, CHARACTER_SIZE), (180, 255, 180))

    return background, character_menu, character_front_small, character_back_small, character_idle_small, character_down_small


def make_blank_background():
    """创建纯白背景窗口。"""
    surface = pygame.Surface((WIDTH, HEIGHT))
    surface.fill((255, 255, 255))
    return surface


def draw_centered_text(surface, text, font, color, y):
    """在窗口指定高度居中显示一行文字。"""
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(WIDTH // 2, y))
    surface.blit(text_surface, text_rect)


def get_level_background(level, background, blank_background):
    """第 0 关用图片背景，其余关卡用纯白背景。"""
    if level == 0:
        return background
    return blank_background


class TouchButton:
    """屏幕虚拟按键。"""

    def __init__(self, name, rect, label, color=(255, 255, 255)):
        self.name = name
        self.rect = pygame.Rect(rect)
        self.label = label
        self.color = color

    def contains(self, pos):
        return self.rect.collidepoint(pos)


class TouchUI:
    """管理屏幕虚拟按键的触控 / 鼠标输入。

    - pressed：当前被按住的按键名集合
    - just_pressed：本帧新按下的按键名集合（用于“跳跃”这种按下即触发）
    同时支持多点触控（FINGER* 事件）和鼠标（桌面 / 浏览器）。
    """

    def __init__(self, buttons):
        self.buttons = buttons
        self._pointer_to_button = {}
        self.pressed = set()
        self.just_pressed = set()

    def clear_frame(self):
        self.just_pressed.clear()

    def _hit(self, pos):
        for btn in self.buttons.values():
            if btn.contains(pos):
                return btn.name
        return None

    def _press(self, pointer_key, pos):
        name = self._hit(pos)
        if name is None:
            return
        if pointer_key in self._pointer_to_button:
            self._release(pointer_key)
        self._pointer_to_button[pointer_key] = name
        self.pressed.add(name)
        self.just_pressed.add(name)

    def _release(self, pointer_key):
        name = self._pointer_to_button.pop(pointer_key, None)
        if name is not None and name not in self._pointer_to_button.values():
            self.pressed.discard(name)

    def is_down(self, name):
        return name in self.pressed

    def handle_event(self, event):
        if event.type == pygame.FINGERDOWN:
            fid = getattr(event, "finger_id", getattr(event, "touch_id", 0))
            pos = (event.x * WIDTH, event.y * HEIGHT)
            self._press(("finger", fid), pos)
        elif event.type == pygame.FINGERUP:
            fid = getattr(event, "finger_id", getattr(event, "touch_id", 0))
            self._release(("finger", fid))
        elif event.type == pygame.FINGERMOTION:
            fid = getattr(event, "finger_id", getattr(event, "touch_id", 0))
            key = ("finger", fid)
            if key in self._pointer_to_button:
                pos = (event.x * WIDTH, event.y * HEIGHT)
                name = self._hit(pos)
                if name != self._pointer_to_button[key]:
                    self._release(key)
                    if name is not None:
                        self._press(key, pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._press(("mouse", 1), event.pos)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self._release(("mouse", 1))

    def draw(self, surface):
        font = get_font(20)
        for btn in self.buttons.values():
            overlay = pygame.Surface(btn.rect.size, pygame.SRCALPHA)
            if btn.name in self.pressed:
                overlay.fill((255, 255, 255, 150))
            else:
                overlay.fill((255, 255, 255, 60))
            surface.blit(overlay, btn.rect.topleft)
            pygame.draw.rect(surface, btn.color, btn.rect, 2)
            text = font.render(btn.label, True, btn.color)
            text_rect = text.get_rect(center=btn.rect.center)
            surface.blit(text, text_rect)


async def menu_scene(window, background, character_menu):
    """主场景（主菜单）：显示背景和人物，等待按任意键或点按屏幕。
    返回 True 表示开始游戏，返回 False 表示关闭程序。"""
    pygame.display.set_caption("无职转生 - 主菜单")

    font_big = get_font(36)
    font_tip = get_font(20)

    clock = pygame.time.Clock()
    blink_timer = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                # 按任意键打开游戏窗口
                return True
            if event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                # 触屏点按 / 鼠标点击也视为“按任意键”
                return True

        # 提示文字闪烁
        blink_timer += 1
        show_tip = (blink_timer // 30) % 2 == 0

        # 绘制主场景
        window.blit(background, (0, 0))
        window.blit(character_menu, (180, 30))
        draw_centered_text(window, "无职转生", font_big, (255, 255, 255), 320)
        if show_tip:
            draw_centered_text(window, "点击屏幕开始游戏", font_tip, (255, 255, 200), 370)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


async def game_scene(window, background, character_front_small, character_back_small, character_idle_small, character_down_small, blank_background):
    """游戏场景：支持键盘（WASD / 方向键 / 空格）和屏幕虚拟按键。"""
    pygame.display.set_caption("无职转生 ——游戏中")

    clock = pygame.time.Clock()

    # 屏幕虚拟按键布局
    touch = TouchUI({
        "left":  TouchButton("left",  (15, 305, 78, 78), "◀"),
        "right": TouchButton("right", (108, 305, 78, 78), "▶"),
        "down":  TouchButton("down",  (WIDTH - 95, 305, 78, 78), "▼"),
        "jump":  TouchButton("jump",  (WIDTH - 188, 305, 78, 78), "跳"),
        "back":  TouchButton("back",  (10, 10, 78, 34), "菜单"),
    })

    level = 0           # 当前窗口编号：0 是游戏窗口，1..15 是纯白背景窗口
    x = 180
    y = float(GROUND_Y)
    vy = 0.0
    jumps_used = 0
    cooldown = 0        # 切换窗口后的过渡冷却

    facing = "front"    # 当前朝向：front 向前（js4），back 向后（js3）

    while True:
        touch.clear_frame()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "menu"
                # 跳跃：空格 / W / 上方向键，二段跳
                if event.key in (pygame.K_SPACE, pygame.K_w, pygame.K_UP):
                    if jumps_used < MAX_JUMPS:
                        vy = JUMP_SPEED
                        jumps_used += 1
            touch.handle_event(event)

        # 触屏按键：跳跃（按下即触发）与返回菜单
        if "jump" in touch.just_pressed:
            if jumps_used < MAX_JUMPS:
                vy = JUMP_SPEED
                jumps_used += 1
        if "back" in touch.just_pressed:
            return "menu"

        # 检测按键（键盘 + 触屏）
        keys = pygame.key.get_pressed()
        moving_left = keys[pygame.K_a] or keys[pygame.K_LEFT] or touch.is_down("left")
        moving_right = keys[pygame.K_d] or keys[pygame.K_RIGHT] or touch.is_down("right")
        moving_down = keys[pygame.K_s] or keys[pygame.K_DOWN] or touch.is_down("down")

        # 冷却递减
        if cooldown > 0:
            cooldown -= 1

        # 水平移动与朝向（按住下键时禁止左右移动）
        if not moving_down:
            if moving_left and not moving_right:
                x -= MOVE_SPEED
                facing = "back"
            elif moving_right and not moving_left:
                x += MOVE_SPEED
                facing = "front"

        # 仅在无冷却时处理窗口切换，避免切换瞬间左右判定互相抵消
        if cooldown == 0:
            # 走到右侧尽头：进入下一个窗口
            if x >= WIDTH - CHARACTER_SIZE and level < TOTAL_LEVELS - 1:
                level += 1
                x = 0
                cooldown = TRANSITION_COOLDOWN

            # 走到左侧尽头：回到前一个窗口
            elif x <= 0 and level > 0:
                level -= 1
                x = WIDTH - CHARACTER_SIZE
                cooldown = TRANSITION_COOLDOWN

        # 垂直移动（重力自动下落）
        vy += GRAVITY
        y += vy

        # 落地检测
        if y >= GROUND_Y:
            y = GROUND_Y
            vy = 0.0
            jumps_used = 0

        # 限制人物在窗口范围内
        x = max(0, min(WIDTH - CHARACTER_SIZE, x))

        # 选择角色图片：下蹲 l6 > 移动 js4/js3 > 站立不动 l1
        if moving_down:
            character = character_down_small
        elif moving_left or moving_right:
            character = character_front_small if facing == "front" else character_back_small
        else:
            character = character_idle_small

        # 绘制当前窗口背景（第 1 个用图片，其余用纯白背景）
        level_background = get_level_background(level, background, blank_background)
        window.blit(level_background, (0, 0))
        window.blit(character, (x, int(y)))

        # 绘制屏幕虚拟按键
        touch.draw(window)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


async def main():
    window = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("无职转生 - 像素游戏")

    background, character_menu, character_front_small, character_back_small, character_idle_small, character_down_small = load_images()
    blank_background = make_blank_background()

    running = True
    while running:
        # 主菜单：按任意键 / 点击屏幕开始（主界面使用 js1）
        start = await menu_scene(window, background, character_menu)

        if start is False:
            running = False
            continue

        # 开始后打开游戏窗口
        result = await game_scene(window, background, character_front_small, character_back_small, character_idle_small, character_down_small, blank_background)

        if result == "quit":
            running = False
        # result == "menu" 则回到主菜单继续循环（仅 ESC / 菜单键会触发）


if __name__ == "__main__":
    asyncio.run(main())
    pygame.quit()


