# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller 打包配置。

用法（在任意目录执行均可，路径用引号包住）：
    pyinstaller --noconfirm --clean "game.spec"
"""
import os

a = Analysis(
    [os.path.join(SPECPATH, 'game.py')],
    pathex=[SPECPATH],
    binaries=[],
    datas=[
        (os.path.join(SPECPATH, '背景'), '背景'),
        (os.path.join(SPECPATH, '角色'), '角色'),
        (os.path.join(SPECPATH, 'fonts'), 'fonts'),
    ],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='无职转生',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # GUI 游戏，不显示命令行窗口
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
